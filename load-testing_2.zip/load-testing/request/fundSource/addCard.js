import http from "k6/http";
import { sleep, group } from 'k6'
// import { userArray } from "../../resources/properties/responseData.js";
const { listOfFundSource } = require("./common.js")
const { properties } = require("../../resources/properties/config.js")

var headerParam

export function addFee(userArray) {
    var url = properties.baseUrl + 'settlements/add-fund/fee'
    userArray.forEach(e => {
        headerParam = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `BEARER ${JSON.parse(e).access_token}`,
                'Ppay-Device-Id': `${JSON.parse(e).device_id}`
            }
        }
        var payload = JSON.stringify({
            "source": "card",
            "type": "visa",
            "amount": 5000
        })

        let feeResponse = http.post(url, payload, headerParam)
        var successData = JSON.parse(feeResponse.body).data
        addCardInfo(successData.invoice_id, headerParam)
    })
}
export function addCardInfo(invoice_id, headerParam) {
    var url = properties.baseUrl + 'settlements/fund-sources/card'
    var payload = JSON.stringify({
        "invoice_id": invoice_id,
        "account_name": "visa Card",
        "card_info": "THXl5SVhWzAMuG3nsFkebPiwaQpx610AYmLuEH47Rqj2s6kTDvKJ9vmD2E/IoxVaHUleOJx6+rLl2sHVYNgCgMNtt3LpNTi6z5LHA8rWMQVTisESgWPPctxc3pgjW0lULOD1obRzRjA2L2JSiT3wkmOVgefoDmd6e/Ybv4MM43ws29Y4pJ+CZhftZ85nJS78gReyGkhOkLQeFjXy928YwYNbL4WdkliPlZ1m90bNF38f+ytyhOyEhqAZHjLJHXEySRvdu+vk6wM+dQhd+qfSfocJC5OJWLJmVXbqxVCcn/XZh0fCLBTF/IZ8+SE5SV1PHbD+rS3aYN3WO0Veo34JHA==",
        "type": "visa"
    })

    let addCardInfoResponse = http.post(url, payload, headerParam)
    if (addCardInfoResponse.status === 200) {
        var data = JSON.parse(addCardInfoResponse.body).data
        visitURL(data.redirect_url)
    }else if(addCardInfoResponse.status === 422){
        var body = JSON.parse(addCardInfoResponse.body)
        console.log("Card Add: Error Code: " + body.code + "\tTitle: " + body.title)
        if(body.code === 'SSFSAE422'){
            // Header Parameter and Source Type, Return Source ID
            var source_id = listOfFundSource(headerParam, 'card')
            console.log(source_id)
        }
    }
     else {
        var body = JSON.parse(addCardInfoResponse.body)
        console.log("Card Add: Error Code: " + body.code + "\tTitle: " + body.title)
    }
}

// Third Party API
export function visitURL(url) {
    let response
    const vars = {}
    response = http.get(url)
    vars['PaReq'] = response.html().find('input[name=PaReq]').first().attr('value')
    vars['MD'] = response.html().find('input[name=MD]').first().attr('value')
    vars['JWT'] = response.html().find('input[name=JWT]').first().attr('value')
    // sleep(0.5)

    response = http.post(
        'https://centinelapistag.cardinalcommerce.com/V2/Cruise/StepUp',
        {
          PaReq: `${vars['PaReq']}`,
          MD: `${vars['MD']}`,
          JWT: `${vars['JWT']}`,
        },
        {
          headers: {
            'content-type': 'application/x-www-form-urlencoded',
            origin: 'https://api.pp-stage.xyz',
            'upgrade-insecure-requests': '1',
            'sec-ch-ua': '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
          },
        }
      )
  
      vars['McsId1'] = response.html().find('input[name=McsId]').first().attr('value')
      vars['orgUnitId1'] = response.html().find('input[name=orgUnitId]').first().attr('value')
      vars['transactionId1'] = response.html().find('input[name=transactionId]').first().attr('value')
      vars['payload1'] = response.html().find('input[name=payload]').first().attr('value')
      vars['termUrl1'] = response.html().find('input[name=termUrl]').first().attr('value')
    //   sleep(0.6)

      response = http.post(
        'https://merchantacsstag.cardinalcommerce.com/MerchantACSWeb/pareq.jsp',
        {
          PaReq: `${vars['payload1']}`,
          MD: `${vars['McsId1']}`,
          TermUrl: `${vars['termUrl1']}`,
          screensubmit: 'true',
          'external.field.username': 'test1',
          'external.field.password': '1234',
          'external.field.password.encoding': 'SHA1',
        },
        {
          headers: {
            'content-type': 'application/x-www-form-urlencoded',
            origin: 'https://merchantacsstag.cardinalcommerce.com',
            'upgrade-insecure-requests': '1',
            'sec-ch-ua': '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
          },
        }
      )
      vars['PaRes1'] = response.html().find('input[name=PaRes]').first().attr('value')
      vars['MD2'] = response.html().find('input[name=MD]').first().attr('value')
      response = http.post(
        'https://centinelapistag.cardinalcommerce.com/V1/TermURL/Overlay/CCA',
        {
          PaRes: `${vars['PaRes1']}`,
          MD: `${vars['MD2']}`,
        },
        {
          headers: {
            'content-type': 'application/x-www-form-urlencoded',
            origin: 'https://merchantacsstag.cardinalcommerce.com',
            'upgrade-insecure-requests': '1',
            'sec-ch-ua': '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
          },
        }
      )
    //   sleep(1)      





      response = http.post(
        'https://api.pp-stage.xyz/w/v1/acs/confirm/cb735d3e-7d3a-4f35-8a06-78ffb3b4bf36',
        {
          TransactionId: `${vars['transactionId1']}`,
          Response: '',
          MD: `${vars['MD']}`,
        },
        {
          headers: {
            'content-type': 'application/x-www-form-urlencoded',
            origin: 'https://centinelapistag.cardinalcommerce.com',
            'upgrade-insecure-requests': '1',
            'sec-ch-ua': '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
          },
        }
      )
      console.log("Card Add" + response.url)

}
module.exports = { addFee }