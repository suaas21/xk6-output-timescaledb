const properties = {
    baseUrl: 'https://api.pp-stage.xyz/api/v1/'
}
module.exports = {properties}