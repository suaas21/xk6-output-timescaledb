
var userArray = []
var loginToken = []

// export function getUserData() {
//     for (var i = 0; i < userArray.length; i++) {

//     }
// }

// export function getUserData() {
//     console.log(`Response : ${loginToken}`)
// }


module.exports = { userArray, loginToken }